---
title: 'Kiểm tra kỹ thuật an toàn'
content:
    limit: 5
    pagination: '1'
    order:
        dir: desc
        by: date
    items: '@self.children'
taxonomy:
    category:
        - 'kiem dinh an toan'
---

#Kiểm tra kỹ thuật an toàn