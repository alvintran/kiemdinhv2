---
title: 'Huấn luyện an toàn'
metadata:
    description: 'Huấn luyện kỹ thuật an toàn là một việc cần thiết với mỗi doanh nghiệp'
content:
    limit: 5
    pagination: '1'
    order:
        dir: desc
        by: date
    items: '@self.children'
---

#Huấn luyện an toàn

Rất vui khi được huấn luyện an toàn cùng các bạn