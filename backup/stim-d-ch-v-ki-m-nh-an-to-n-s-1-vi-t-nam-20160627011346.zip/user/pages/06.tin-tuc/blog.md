---
title: 'Tin tức'
content:
    limit: 5
    pagination: '1'
    order:
        dir: desc
        by: date
    items: '@self.children'
---

