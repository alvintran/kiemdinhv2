---
title: Cache

access:
    admin.maintenance: true
    admin.super: true
---
