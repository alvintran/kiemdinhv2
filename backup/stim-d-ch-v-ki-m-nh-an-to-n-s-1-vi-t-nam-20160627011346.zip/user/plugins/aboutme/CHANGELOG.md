# v1.1.1
## 04/21/2016

1. [](#improved)
    * The description can now contains markdown and break lines

# v1.1.1
## 03/03/2016

1. [](#bugfix)
    * Fix hardcoded `http` reference for gravatar that breaks https websites

# v1.1.0
## 12/25/2015

1. [](#improved)
    * Changed the social pages feature. You can now pick a different font icon from font-awesome, change the order the links will appear in, and also change the title which will appear when the icon is hovered. You might want to change your own `aboutme.yaml` in your user config with the new `aboutme.yaml` so the plugin does not break
2. [](#bugfix)
    * The source of the avatar was broken when used with multi-languages. It's now fixed

# v1.0.0
## 12/21/2015

1. [](#new)
    * First Version
    * ChangeLog started...
